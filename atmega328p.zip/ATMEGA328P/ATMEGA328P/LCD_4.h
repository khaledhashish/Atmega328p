/*
 * LCD_4.h
 *
 * Created: 10/9/2020 1:47:26 PM
 *  Author: khaled
 */ 



#ifndef LCD_4_H_
#define LCD_4_H_


#endif /* LCD_4_H_ */

void LCD_cmd(char);
void LCD_init();
void LCD_Write(char);
void LCD_Write_Str(char*);
void LCD_num(int);
void LCD_Clear();
void LCD_Home();